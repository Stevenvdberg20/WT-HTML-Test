package com.example.demo.controller;

import com.example.demo.domein.Gebruiker;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;
import org.springframework.data.jpa.repository.Query;

@Component
public interface gebruikerRepository extends CrudRepository<Gebruiker, Long> {
    @Query("SELECT g.naam FROM Gebruiker g") // HIJ DOET HET!!!!!!
    List<String> getNaam();

}
 