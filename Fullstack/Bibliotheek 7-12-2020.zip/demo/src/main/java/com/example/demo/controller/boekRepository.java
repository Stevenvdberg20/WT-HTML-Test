package com.example.demo.controller;

import com.example.demo.domein.Boek;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public interface boekRepository extends CrudRepository<Boek, Long> {
    List<Boek> findByTitel(String titel);

    //long countTitelDistinctByUitgeleend(boolean ul);
    //long countDistinctTitel();

    //List<Boek> findDistinctByTitel(Boek boek);
    // @Query("select distinct bk.titel from Boek bk")
    // List<Boek> findDistinctBoekByTitel(Boek boek);

    // @Query(value = "select distinct b.Titel from Boek b",nativeQuery = true)
    // List<Boek> findDistinctALL();
    //@Query("SELECT DISTINCT boek.titel FROM Boek boek")
    //List<String> findNonReferencedNames(List<String> names);
}
