package com.example.demo.controller;

import com.example.demo.domein.Gebruiker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class gebruikerController {

    @Autowired
    gebruikerRepository gr;


    public void gebruikerOpslaan(Gebruiker gebruiker) {
        gr.save(gebruiker);
    }

    public Iterable<Gebruiker> alleGebruikers() {
        return gr.findAll();
    }
    	
    public List<String> alleGebruikersNamen() {
        List<String> alleGebruikers = new ArrayList<String>();
        for (Gebruiker g: gr.findAll()) {
            alleGebruikers.add(g.getNaam());
            
        }
        return alleGebruikers;
    }

    public void getTest() {
        List<String> test = gr.getNaam();
        for(String s: test) {
            System.out.println(s);
        }
    }
}
